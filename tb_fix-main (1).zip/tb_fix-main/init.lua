-- ==========================================
-- TECHBLOX OPTIMIZATION & FIXES (All-in-One)
-- ==========================================

-- 1. ENGINE PERFORMANCE OVERRIDES
-- These force the server to work less on background tasks
local settings = minetest.settings
settings:set("active_block_range", "1")            -- Only process stuff close to players
settings:set("max_block_generate_distance", "3")    -- Stop exploration lag
settings:set("server_map_save_interval", "120")     -- Save world less often (saves CPU)
settings:set("sqlite_synchronous", "0")             -- Faster database writing
settings:set("abm_interval", "2.0")                 -- Run mod tasks half as often
settings:set("active_block_mgmt_interval", "2.0")   -- Slow down chunk management
settings:set("ignore_world_load_errors", "true")    -- Don't panic over missing nodes

minetest.log("action", "[z_fix] Engine performance settings forced.")

-- 2. GHOST NODE ALIASES (Fixes Console Spam)
-- This turns the "unknown" plantlife nodes into air
minetest.register_on_mods_loaded(function()
    local missing_nodes = {
        "bushes:BushLeaves",
        "bushes:BushLeaves1",
        "bushes:BushStem",
        "nature_lib:blossom",
        "flowers:mushroom_red", -- Just in case others were deleted
    }

    for _, node_name in ipairs(missing_nodes) do
        minetest.register_alias(node_name, "air")
    end
    minetest.log("action", "[z_fix] Ghost nodes aliased to air.")
end)

-- 3. MOD-SPECIFIC THROTTLING
-- We wait until mods are initialized to override their internal logic
minetest.register_on_mods_loaded(function()
    -- Throttle Mobs Redo (Huge CPU saver)
    if minetest.get_modpath("mobs") then
        mobs.spawn_rate = 0.5    -- Double the time between spawns
        mobs.active_limit = 15   -- Limit total mobs on server
        minetest.log("action", "[z_fix] Mobs Redo throttled.")
    end

    -- Throttle 3D Armor
    if minetest.get_modpath("3d_armor") then
        if armor and armor.config then
            armor.config.update_time = 3.0 -- Update every 2s
        end
        minetest.log("action", "[z_fix] 3D Armor updates slowed.")
    end

    -- Throttle Mesecons
    if minetest.get_modpath("mesecons") then
        if mesecon then
            mesecon.interval = 0.5 -- Slower logic circuits
        end
        minetest.log("action", "[z_fix] Mesecons logic slowed.")
    end
end)

-- 4. EMERGENCY DATABASE CLEANUP (Optional)
minetest.register_on_joinplayer(function(player)
    local name = player:get_player_name()
    if minetest.check_player_privs(name, {server=true}) then
        minetest.chat_send_player(name, "Techblox Optimization: Run /clearobjects quick if lag persists.")
    end
end)

minetest.log("action", "[z_fix] ALL-IN-ONE Optimization Mod Loaded!")
