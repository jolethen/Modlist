local modpath = minetest.get_modpath(minetest.get_current_modname())

-- Load each command/system
dofile(modpath .. "/rulles.lua")
dofile(modpath .. "/repoorts.lua")
dofile(modpath .. "/guuide.lua")
dofile(modpath .. "/events.lua")
dofile(modpath .. "/online.lua")
dofile(modpath .. "/changelog.lua")
dofile(modpath .. "/random_messages.lua")
