local S = minetest.get_translator("whitelist")

minetest.register_on_prejoinplayer(function(name, ip)
  if not whitelist.is_whitelist_enabled() then return end

  if not whitelist.is_player_whitelisted(name) and not core.check_player_privs(name, "server") and name ~= "singleplayer" then
    return S("You're not whitelisted!")
  end
end)
